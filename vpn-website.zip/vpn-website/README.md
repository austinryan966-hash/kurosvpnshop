# Outline VPN site – Cloudflare Pages setup
1. Cloudflare > Workers & Pages > Create > Pages > Connect to Git > pick this repo.
   Framework: None. Build command: (empty). Build output directory: /  (use . if / is rejected).
2. Cloudflare > Storage & databases > KV > create a namespace (e.g. vpn-orders).
3. Pages project > Settings > Bindings > Add > KV namespace: Variable name ORDERS, pick the namespace.
4. Pages project > Settings > Variables and secrets: add ADMIN_PASSWORD (required),
   TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID (optional alerts).
5. Redeploy (Deployments > latest > Retry), then open /admin.html.
Business info (brand, prices, payments, Telegram) is in config.js. Burmese text is in i18n.js.
QR codes: assets/qr-kbzpay.png, assets/qr-wavepay.png. Tutorial images: assets/tutorial/.
